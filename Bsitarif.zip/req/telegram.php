<?php
$telegram_id = "7129925540:AAFqFFcboFzIc6onw2dRlMNJ-sJiVKi-zX0"; // ID TELEGRAM
$id_bot = "6042961009"; // TOKEN BOT ID
?>
